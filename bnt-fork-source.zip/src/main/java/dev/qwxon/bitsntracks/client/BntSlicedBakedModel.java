package dev.qwxon.bitsntracks.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;

/**
 * Keeps only the quads whose centre lies in {@code [min, max]} along the axle.
 * Used to take the original outer faces of a wheel instead of squashing the
 * whole model into a thin disk.
 */
public final class BntSlicedBakedModel implements BakedModel {
   private final BakedModel src;
   private final Axis axis;
   private final float min;
   private final float max;

   public BntSlicedBakedModel(BakedModel src, Axis axis, float min, float max) {
      this.src = src;
      this.axis = axis;
      this.min = min;
      this.max = max;
   }

   @Override
   public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource rand) {
      return filter(this.src.getQuads(state, side, rand));
   }

   @Override
   public List<BakedQuad> getQuads(
      @Nullable BlockState state,
      @Nullable Direction side,
      RandomSource rand,
      ModelData data,
      @Nullable RenderType type
   ) {
      return filter(this.src.getQuads(state, side, rand, data, type));
   }

   private List<BakedQuad> filter(List<BakedQuad> in) {
      if (in == null || in.isEmpty()) {
         return in == null ? List.of() : in;
      }
      List<BakedQuad> out = new ArrayList<>(in.size());
      for (BakedQuad quad : in) {
         float center = centroid(quad, this.axis);
         if (center >= this.min && center <= this.max) {
            out.add(quad);
         }
      }
      return out;
   }

   static float centroid(BakedQuad quad, Axis axis) {
      int[] data = quad.getVertices();
      int stride = data.length / 4;
      float sum = 0.0F;
      for (int i = 0; i < 4; i++) {
         int o = i * stride;
         float x = Float.intBitsToFloat(data[o]);
         float y = Float.intBitsToFloat(data[o + 1]);
         float z = Float.intBitsToFloat(data[o + 2]);
         sum += switch (axis) {
            case X -> x;
            case Y -> y;
            case Z -> z;
         };
      }
      return sum * 0.25F;
   }

   @Override
   public boolean useAmbientOcclusion() {
      return this.src.useAmbientOcclusion();
   }

   @Override
   public boolean isGui3d() {
      return this.src.isGui3d();
   }

   @Override
   public boolean usesBlockLight() {
      return this.src.usesBlockLight();
   }

   @Override
   public boolean isCustomRenderer() {
      return this.src.isCustomRenderer();
   }

   @Override
   public TextureAtlasSprite getParticleIcon() {
      return this.src.getParticleIcon();
   }

   @Override
   public ItemTransforms getTransforms() {
      return this.src.getTransforms();
   }

   @Override
   public ItemOverrides getOverrides() {
      return this.src.getOverrides();
   }
}
