package dev.qwxon.bitsntracks.client;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import dev.engine_room.flywheel.api.instance.InstancerProvider;
import dev.engine_room.flywheel.api.model.Model;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.TransformedInstance;
import dev.engine_room.flywheel.lib.model.Models;
import dev.qwxon.bitsntracks.access.KineticBlockEntityPhysicsAccess;
import dev.qwxon.bitsntracks.content.HiddenCogwheelCompat;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Draws the checkerboard halves through Flywheel so they match the lighting
 * of a regular wheel (Iris / irisflw included). Each half is an unscaled
 * slice of the original wheel, so the outer side faces stay identical.
 */
public final class BntCheckerFlywheel {
   private final InstancerProvider instancers;
   private TransformedInstance minus;
   private TransformedInstance plus;
   private TransformedInstance shaft;
   private Axis shaftAxis;
   private BlockState bakedState;

   public BntCheckerFlywheel(InstancerProvider instancers, Model wheelModel) {
      this.instancers = instancers;
   }

   /**
    * @return true if checker is on and the default rotating model must stay hidden
    */
   public boolean apply(
      KineticBlockEntity be,
      KineticBlockEntityPhysicsAccess access,
      float alignX,
      float alignY,
      float alignZ,
      BlockPos visualPos
   ) {
      if (access.bnt$getChecker() == BntCheckerRenderer.OFF) {
         this.delete();
         return false;
      }
      if (!be.getBlockState().hasProperty(net.minecraft.world.level.block.state.properties.BlockStateProperties.AXIS)) {
         this.delete();
         return false;
      }
      BntCheckerLayout layout = BntCheckerLayout.compute(be, access);
      BlockState renderState = visibleState(be);
      this.ensure(renderState, layout.axis);
      float angle = spinAngle(be, layout.axis, layout.radius);
      float x = visualPos.getX() + alignX;
      float y = visualPos.getY() + alignY;
      float z = visualPos.getZ() + alignZ;
      if (layout.axis == Axis.X) {
         x += layout.shift;
      } else if (layout.axis == Axis.Y) {
         y += layout.shift;
      } else {
         z += layout.shift;
      }
      if (layout.showMinus) {
         poseSlice(this.minus, x, y, z, layout.axis, layout.radius, angle);
      } else {
         hide(this.minus);
      }
      if (layout.showPlus) {
         poseSlice(this.plus, x, y, z, layout.axis, layout.radius, angle);
      } else {
         hide(this.plus);
      }
      poseDisk(this.shaft, x, y, z, layout.axis, layout.shaftCenter(), layout.shaftLen(), layout.radius, angle);
      return true;
   }

   public void relightInto(java.util.function.Consumer<TransformedInstance> relight) {
      if (this.minus != null) {
         relight.accept(this.minus);
      }
      if (this.plus != null) {
         relight.accept(this.plus);
      }
      if (this.shaft != null) {
         relight.accept(this.shaft);
      }
   }

   public void delete() {
      if (this.minus != null) {
         this.minus.delete();
         this.minus = null;
      }
      if (this.plus != null) {
         this.plus.delete();
         this.plus = null;
      }
      if (this.shaft != null) {
         this.shaft.delete();
         this.shaft = null;
      }
      this.shaftAxis = null;
      this.bakedState = null;
   }

   private void ensure(BlockState renderState, Axis axis) {
      if (this.minus != null && renderState.equals(this.bakedState) && this.shaftAxis == axis) {
         return;
      }
      this.delete();
      this.minus = this.instancers.instancer(InstanceTypes.TRANSFORMED, BntCheckerSlices.flywheel(renderState, false)).createInstance();
      this.plus = this.instancers.instancer(InstanceTypes.TRANSFORMED, BntCheckerSlices.flywheel(renderState, true)).createInstance();
      this.shaft = this.instancers
         .instancer(InstanceTypes.TRANSFORMED, Models.block(KineticBlockEntityRenderer.shaft(axis)))
         .createInstance();
      this.shaftAxis = axis;
      this.bakedState = renderState;
   }

   private static BlockState visibleState(KineticBlockEntity be) {
      BlockState state = be.getBlockState();
      if (HiddenCogwheelCompat.isHiddenCogwheel(state)) {
         BlockState vis = HiddenCogwheelCompat.toVisibleRenderState(state, be);
         if (vis != null) {
            return vis;
         }
      }
      return state;
   }

   /** Unscaled slice — already sits at the regular wheel's outer face. */
   private static void poseSlice(
      TransformedInstance inst,
      float x,
      float y,
      float z,
      Axis axis,
      float radius,
      float angle
   ) {
      inst.setIdentityTransform().translate(x, y, z).translate(0.5F, 0.5F, 0.5F);
      if (Math.abs(radius - 1.0F) > 0.001F) {
         switch (axis) {
            case X -> inst.scale(1.0F, radius, radius);
            case Y -> inst.scale(radius, 1.0F, radius);
            case Z -> inst.scale(radius, radius, 1.0F);
         }
      }
      inst.rotateCentered(angle, Direction.get(Direction.AxisDirection.POSITIVE, axis));
      inst.translate(-0.5F, -0.5F, -0.5F);
      inst.setChanged();
   }

   private static void poseDisk(
      TransformedInstance inst,
      float x,
      float y,
      float z,
      Axis axis,
      float center,
      float thick,
      float radius,
      float angle
   ) {
      float mid = center - 0.5F;
      inst.setIdentityTransform().translate(x, y, z).translate(0.5F, 0.5F, 0.5F);
      switch (axis) {
         case X -> {
            inst.translate(mid, 0.0F, 0.0F);
            inst.scale(thick, radius, radius);
         }
         case Y -> {
            inst.translate(0.0F, mid, 0.0F);
            inst.scale(radius, thick, radius);
         }
         case Z -> {
            inst.translate(0.0F, 0.0F, mid);
            inst.scale(radius, radius, thick);
         }
      }
      inst.rotateCentered(angle, Direction.get(Direction.AxisDirection.POSITIVE, axis));
      inst.translate(-0.5F, -0.5F, -0.5F);
      inst.setChanged();
   }

   private static void hide(TransformedInstance inst) {
      inst.setIdentityTransform().translate(0.0F, -10000.0F, 0.0F).setChanged();
   }

   private static float spinAngle(KineticBlockEntity be, Axis axis, float radius) {
      float scale = Math.max(0.25F, radius);
      float time = AnimationTickHolder.getRenderTime(be.getLevel());
      float offset = KineticBlockEntityRenderer.getRotationOffsetForPosition(be, be.getBlockPos(), axis);
      float angle = (time * (be.getSpeed() / scale) * 3.0F / 10.0F + offset) % 360.0F;
      return angle / 180.0F * (float)Math.PI;
   }
}
