package dev.qwxon.bitsntracks.client;

import dev.qwxon.bitsntracks.access.KineticBlockEntityPhysicsAccess;
import dev.qwxon.bitsntracks.physics.BntWheelWidth;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/** Shared geometry for the checkerboard wheel (BER and Flywheel). */
public final class BntCheckerLayout {
   /** 2px of shaft past the remaining disk when the outer half is hidden. */
   public static final float OUTER_STUB = 0.125F;

   public Axis axis;
   public int sign;
   public int mode;
   public float from;
   public float to;
   public float span;
   public float radius;
   public float shift;
   public boolean showMinus;
   public boolean showPlus;
   public float shaftFrom;
   public float shaftTo;

   private BntCheckerLayout() {
   }

   public static BntCheckerLayout compute(BlockEntity be, KineticBlockEntityPhysicsAccess access) {
      BntCheckerLayout l = new BntCheckerLayout();
      l.mode = access.bnt$getChecker();
      var state = be.getBlockState();
      l.axis = state.getValue(BlockStateProperties.AXIS);
      l.sign = BntWheelWidth.outwardSign(be.getLevel(), be.getBlockPos(), l.axis, be);
      float width = access.bnt$getTrackWidth();
      // Always one block — same as a regular wheel. Extra track width only
      // shifts the whole pair outward, it does not make the pair wider.
      l.from = 0.0F;
      l.to = 1.0F;
      l.span = 1.0F;
      l.shift = (float)BntWheelWidth.centerShift(width, l.sign);
      l.showMinus = l.mode != BntCheckerRenderer.HIDE_MINUS;
      l.showPlus = l.mode != BntCheckerRenderer.HIDE_PLUS;
      l.radius = access.bnt$getRadiusScale();
      l.shaftFrom = l.from;
      l.shaftTo = l.to;
      boolean hideOuter = l.sign < 0 ? !l.showMinus : !l.showPlus;
      if (hideOuter) {
         float inner = BntCheckerSlices.SLICE_INNER;
         if (l.sign < 0) {
            l.shaftFrom = l.to - inner - OUTER_STUB;
            l.shaftTo = l.to;
         } else {
            l.shaftFrom = l.from;
            l.shaftTo = l.from + inner + OUTER_STUB;
         }
      }
      return l;
   }

   public float shaftCenter() {
      return (this.shaftFrom + this.shaftTo) * 0.5F;
   }

   public float shaftLen() {
      return Math.max(0.02F, this.shaftTo - this.shaftFrom);
   }
}
