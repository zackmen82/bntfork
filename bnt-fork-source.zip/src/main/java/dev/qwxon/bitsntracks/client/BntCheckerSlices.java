package dev.qwxon.bitsntracks.client;

import dev.engine_room.flywheel.api.model.Model;
import dev.engine_room.flywheel.lib.model.baked.BakedModelBuilder;
import dev.engine_room.flywheel.lib.util.RendererReloadCache;
import net.createmod.catnip.render.SuperBufferFactory;
import net.createmod.catnip.render.SuperByteBuffer;
import net.createmod.catnip.render.SuperByteBufferCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Outer-end slices of a regular wheel. Each half keeps the original side
 * face (flange + teeth) instead of a squashed copy of the whole model.
 */
public final class BntCheckerSlices {
   /** Drop the middle ~2px so the shaft is the only thing in the gap. */
   public static final float CUT = 0.49F;
   /** Approximate inner edge of a kept half, for the hidden-outer shaft stub. */
   public static final float SLICE_INNER = 0.45F;

   public record Key(BlockState state, boolean plus) {
   }

   private static final RendererReloadCache<Key, Model> FLYWHEEL = new RendererReloadCache<>(BntCheckerSlices::bakeFlywheel);
   private static final SuperByteBufferCache.Compartment<Key> BER = new SuperByteBufferCache.Compartment<>();
   private static boolean berReady;

   private BntCheckerSlices() {
   }

   public static Model flywheel(BlockState state, boolean plus) {
      return FLYWHEEL.get(new Key(state, plus));
   }

   public static SuperByteBuffer buffer(BlockState state, boolean plus) {
      ensureBer();
      Key key = new Key(state, plus);
      return SuperByteBufferCache.getInstance()
         .get(BER, key, () -> SuperBufferFactory.getInstance().createForBlock(slice(state, plus), state));
   }

   public static BakedModel slice(BlockState state, boolean plus) {
      BakedModel src = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
      Axis axis = state.hasProperty(BlockStateProperties.AXIS)
         ? state.getValue(BlockStateProperties.AXIS)
         : Axis.Y;
      float min = plus ? 1.0F - CUT : 0.0F;
      float max = plus ? 1.0F : CUT;
      return new BntSlicedBakedModel(src, axis, min, max);
   }

   private static Model bakeFlywheel(Key key) {
      return new BakedModelBuilder(slice(key.state, key.plus)).build();
   }

   private static synchronized void ensureBer() {
      if (!berReady) {
         SuperByteBufferCache.getInstance().registerCompartment(BER);
         berReady = true;
      }
   }
}
