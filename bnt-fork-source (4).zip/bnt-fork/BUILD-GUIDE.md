# Как устроен проект и как выпускается новая версия

Документ для быстрого восстановления контекста (для меня-помощника в новых сессиях и для вас).

## Что это

Форк мода **Create: Bits 'n' Tracks** (`bits_n_tracks`, NeoForge 1.21.1), восстановленный
декомпиляцией из `bits_n_tracks-1.0.3.1-release.jar` (лицензия GPL-3.0 — форк легален).
Группа пакетов: `dev.qwxon.bitsntracks`.

## Структура

```
bnt-fork/
├── build.sh                  ← сборка одной командой (см. ниже)
├── gradle.properties         ← версия мода: mod_version=1.3.9-fork
├── build.gradle              ← зависимости = локальные JAR из libs/
├── settings.gradle
├── libs/                     ← 9 JAR-зависимостей (скачиваются публично, см. список ниже)
└── src/main/
    ├── java/dev/qwxon/bitsntracks/
    │   ├── BitsNTracks.java           главный класс мода
    │   ├── content/CogAlignmentLeverItem.java   инструмент (5 режимов)
    │   ├── content/BntToolMode.java             режимы: ALIGN/GRIP/WIDTH/RADIUS/REST
    │   ├── physics/BntTrackSettings.java        константы: grip 25–300%, ширина
    │   │                                        0.875–2 блока, радиус 25–175%
    │   ├── physics/BntPhysicsEvents.java        физика: grip, жёсткие катки
    │   ├── physics/BntPhysicsRegistry.java      реестр «жёстких» (неактивных) катков
    │   ├── physics/CogwheelSizeHelper.java      радиусы/масштаб катков
    │   ├── physics/BntRadiusProvider.java       ThreadLocal для ленивого ребилда геометрии
    │   ├── client/BntChainWidthCache.java       кэш ширины ленты (оптимизация FPS)
    │   ├── client/BntRestTrackHelper.java       «лежачая гусеница» (тигр-режим)
    │   ├── mixin/KineticBlockEntityPhysicsMixin.java  NBT: BntGrip, BntTrackWidth,
    │   │                                            BntRadiusScale, BntRestTrack
    │   ├── mixin/CogwheelChain(Mixin/BehaviourMixin/...)  геометрия цепи/лента
    │   └── mixin/RotationPropagatorMixin.java   передача большая↔средняя/мелкая шестерня
    └── resources/
        ├── META-INF/neoforge.mods.toml          манифест (version= лотже дублируется!)
        ├── bits_n_tracks.mixins.json            список миксинов
        └── assets/bits_n_tracks/lang/           переводы en_us/ru_ru
```

## Зависимости (libs/) — откуда берутся

| Файл | Источник |
|---|---|
| create-1.21.1-6.0.10.jar | Modrinth `create` |
| flywheel-neoforge-1.21.1-1.0.6.jar | внутри create (`META-INF/jarjar/`) |
| ponder-neoforge-1.0.82+mc1.21.1.jar | внутри create (`META-INF/jarjar/`) |
| Registrate-MC1.21-1.3.0+67.jar | внутри create (`META-INF/jarjar/`) |
| azimuth-1.4.2.jar | Modrinth `azimuth-api` (RpH8tmT1) |
| struts-1.2.7.jar | Modrinth `strut-your-stuff` (sHO3MhQx) |
| sable-companion-common-1.21.1-1.5.0.jar | внутри struts (`META-INF/jarjar/`) |
| bits_n_bobs-2.0.2.jar | GitHub qwxon/Create-Bits-n-Bobs-for-Tracks, релиз v2.0.2 |
| sable-neoforge-1.21.1-2.0.3.jar | лежит в репозитории (PolyForm Shield — НЕЛЬЗЯ встраивать в мод) |

## Песочница: ограничения и обходы

- RAM ~2 ГБ, CPU 2 ядра. Этап `decompile` (vineflower) ест до ~2 ГБ → **обязателен swap**
  и снятие `memory.high` cgroup, иначе `createMinecraftArtifacts` вылетает молча
  (OOM-kill видно через `sudo dmesg | grep Killed`).
- JDK 21 качается в /tmp (не сохраняется между сессиями — build.sh перекачает сам).
- Первая сборка (с нулевым кэшем Gradle): ~11 минут. Дальнейшие: ~10 секунд.
- Сборка = `./gradlew jar`, результат в `build/libs/`.

## Чек-лист выпуска новой версии

1. Правки кода.
2. Поднять версию в **двух** местах: `gradle.properties` (`mod_version=`) и
   `src/main/resources/META-INF/neoforge.mods.toml` (`version= "..."`).
3. `bash build.sh`
4. Скопировать JAR в /home/user/ и отдать пользователю (present_file).
5. Обновить архив исходников `bnt-fork-source.zip` (src + gradle-файлы, БЕЗ libs,
   build, .gradle) — пользователь заливает его на GitHub как резервную копию.

## Открытые хвосты на момент 1.3.9+

- Фикс «торчащих верхушек» лежачей гусеницы (релиз 1.4.0) существовал в старой
  сессии, но в GitHub-исходники (1.3.9) НЕ попал → пере-применить: в
  `BntRestTrackHelper` для скрытых/физических катков использовать базовый
  ВИЗУАЛЬНЫЙ радиус (не уменьшенный collision-радиус).
- StackOverflowError у пользователя (бесконечная рекурсия
  RotationPropagator ⇄ CompactSpeedRegulatorBlockEntity из мода
  create_compact_transmission; краш на версии 1.3.7). Удалять наш
  RotationPropagatorMixin НЕЛЬЗЯ (просил пользователь) → делать
  re-entrancy-защиту отдельным миксином по имени класса (без зависимости от
  их мода).

## 1.4.4 (2026-08-01)
- **Stress config restored** (user request): BntServerConfig again has the [physics.stress]
  section with tiny/small/medium/largeStressImpact keys (range 0..4096, per-1-RPM impact,
  Create multiplies by speed). DEFAULTS ARE 0.0 — wheels do not load the kinetic network;
  pre-1.4.3 defaults were 2/4/6/8. BntStressValues provider now returns
  () -> BntServerConfig.getStressImpact(block). Old config files keep their saved values.
- **Phantom power from broken TFMG engines fixed**: engines whose structure was destroyed
  (the very state the crash left behind) kept generating rotation forever -> after world
  reload tracks spun "by themselves". Added bnt$canGenerateSpeedSafely to
  TfmgEngineSafetyMixin: replaces canGenerateSpeed()Z on AbstractSmallEngineBlockEntity
  (Regular engines inherit it; Radial/Turbine override with own gone-safe versions and are
  untouched). Now: own state must be SHAFT (original rule) AND every block of the engine
  row behind the shaft must still have the ENGINE_STATE property, else no output
  (getGeneratedSpeed -> 0 -> applyNewSpeed propagates stop). engineLength() = engines list
  size; row = pos.relative(shaftFacing.opposite(), i) for i=1..min(len,16).
- TFMG internals learned: GeneratingKineticBlockEntity.updateGeneratedRotation calls
  getGeneratedSpeed FIRST then calculateAddedStressCapacity (->hasTwoShafts); crash #3
  hit the latter because the controller block itself was intact. LargeEngine is a separate
  hierarchy (drives PoweredShaft) — not covered, not crashy in the same way.

## 1.4.6 (2026-08-02) — последний чужой миксин убран, форк 100% чистый
- Removed mixin/compat/CompactSpeedRegulatorReentryGuardMixin.java (protection against the
  RotationPropagator ⇄ create_compact_transmission recursion) + its mixins.json entry;
  mixin/compat/ is empty again. The protection NOW LIVES in tfmg-engine-fix 1.1.0
  (CompactRegulatorSafetyMixin + CompactSpeedLimiterSafetyMixin, ThreadLocal + input-speed
  cache). User MUST update both files together.
- mixins.json re-validated: 12 server mixins (all bits_n_tracks own) + 9 client, JSON valid.
- Search over src/: 0 matches for tfmg / drmangotea / lucse / compact — форк содержит
  ТОЛЬКО код Bits 'n' Tracks. Nothing else changed (stress config 0-defaults stay).

## 1.4.5 (2026-08-01) — TFMG logic MOVED OUT of the fork
- User decision: the fork must not touch TFMG at all. Removed:
  - mixin/compat/TfmgEngineSafetyMixin.java (deleted)
  - its entry in bits_n_tracks.mixins.json
  - build.gradle compileOnly tfmg line; libs/tfmg-1.2.0.jar moved to /home/user/tfmg-engine-fix
- Everything else identical to 1.4.4 (stress config with 0-defaults stays).
- The TFMG fixes (air-crash guard + phantom-power stop) now live in the separate
  mod project /home/user/tfmg-engine-fix → jar tfmg_engine_fix-1.0.0.jar
  (modid tfmg_engine_fix, mixin SmallEngineSafetyMixin, TFMG as compileOnly,
  optional dep in mods.toml — silently inert without TFMG installed).

## 1.4.7-fork (2026-08-02)
- Исправлено «самодвижение»: если колесо/гусеница осталось без сети Create
  (источник удалён, сеть распалась), но в NBT блока сохранилась старая
  скорость — тикающий обработчик теперь сбрасывает такую «призрачную»
  скорость в 0 на сервере. Без этого блоки визуально крутились вечно и
  вечно же толкали корпус (танк ехал сам, без двигателя).
